package utn.tienda_libro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaLibroApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaLibroApplication.class, args);
	}

}
