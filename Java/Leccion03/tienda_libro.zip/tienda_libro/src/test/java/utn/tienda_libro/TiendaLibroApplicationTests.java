package utn.tienda_libro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaLibroApplicationTests {

	@Test
	void contextLoads() {
	}

}
